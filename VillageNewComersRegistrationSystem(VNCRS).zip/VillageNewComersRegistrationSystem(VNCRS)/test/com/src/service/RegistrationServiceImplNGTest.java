/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.src.service;

import com.src.domain.Profile;
import com.src.domain.Children;
import com.src.domain.Person;
import com.src.domain.PreviousCountry;
import com.src.domain.Property;
import com.src.domain.Status;
import java.time.LocalDate;
import java.time.Month;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author emmanuel
 */
public class RegistrationServiceImplNGTest {
    
    int nid = 119980000;
    Profile profile = new Profile("Daphnet", "Umutoniwase", LocalDate.of(1998, Month.SEPTEMBER, 23), "umutoniwasedaph@gmail.com", "0784725867", Status.Single, "student", 0);
    Property property = new Property(false, true, true);
    PreviousCountry previousCountry = new PreviousCountry("250", "Rwanda", "Gasabo,Kimironko");
    Person person = new Person();
    RegistrationService registrationService = new RegistrationServiceImpl();
    
    public RegistrationServiceImplNGTest() {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @Test
    public void testGenerateSocialClass() {
        
    }

    @Test
    public void testRegisterNewPerson() {
        person = registrationService.registerNewPerson(nid, profile, property, previousCountry);
        Assert.assertEquals(person.getNid(), nid);
    }

    @Test
    public void testGetPerson() {
    }

    @Test
    public void testSetPerson() {
    }

    @Test
    public void testGetChildrens() {
    }

    @Test
    public void testSetChildrens() {
    }
    
}
