/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.src.domain;

/**
 *
 * @author emmanuel
 */
public class Property {
    private boolean car;
    private boolean house;
    private boolean furnitures;

    public Property() {
    }

    
    public Property(boolean car, boolean house, boolean furnitures) {
        this.car = car;
        this.house = house;
        this.furnitures = furnitures;
    }

    public boolean isCar() {
        return car;
    }

    public void setCar(boolean car) {
        this.car = car;
    }

    public boolean isHouse() {
        return house;
    }

    public void setHouse(boolean house) {
        this.house = house;
    }

    public boolean isFurnitures() {
        return furnitures;
    }

    public void setFurnitures(boolean furnitures) {
        this.furnitures = furnitures;
    }
}
