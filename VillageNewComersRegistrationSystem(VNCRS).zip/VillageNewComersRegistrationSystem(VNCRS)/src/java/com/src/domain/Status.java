/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.src.domain;

/**
 *
 * @author emmanuel
 */
public enum Status {
    Single,
    Married,
    Divorced
}
