/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.src.domain;

/**
 *
 * @author emmanuel
 */

public class SocialClass {
    private String upper;
    private String middle;
    private String working;
    private String poor;

    public SocialClass() {
    }   
    
    public SocialClass(String upper, String middle, String working) {
        this.upper = upper;
        this.middle = middle;
        this.working = working;
    }

    public String getUpper() {
        return upper;
    }

    public void setUpper(String upper) {
        this.upper = upper;
    }

    public String getMiddle() {
        return middle;
    }

    public void setMiddle(String middle) {
        this.middle = middle;
    }

    public String getWorking() {
        return working;
    }

    public void setWorking(String working) {
        this.working = working;
    }

    public String getPoor() {
        return poor;
    }

    public void setPoor(String poor) {
        this.poor = poor;
    }
}
