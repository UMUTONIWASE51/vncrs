/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.src.domain;

/**
 *
 * @author emmanuel
 */
public class User {
    private String nid;
    private String fname;
    private String lname;
    private String username;
    private String phone;
    private String password;

    public User() {
    }

    
    public User(String nid, String fname, String lname, String username, String phone, String password) {
        this.nid = nid;
        this.fname = fname;
        this.lname = lname;
        this.username = username;
        this.phone = phone;
        this.password = password;
    }

    public String getNid() {
        return nid;
    }

    public void setNid(String nid) {
        this.nid = nid;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
