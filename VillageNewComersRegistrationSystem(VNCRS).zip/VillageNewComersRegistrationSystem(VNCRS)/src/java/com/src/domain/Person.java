/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.src.domain;

import java.time.LocalDate;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;

/**
 *
 * @author emmanuel
 */
@Entity
public class Person {
    @Id
    private int nid;
    private String fname;
    private String lname;
    private LocalDate dob;
    private String email;
    private String phone;
    @Enumerated(EnumType.STRING)
    private Status status;
    private int children;
    private String occupation;
    private String socialClass;
    private String previousCountry;

    public Person() {
    }

    public Person(int nid, String fname, String lname, LocalDate dob, String email, String phone, Status status, int children, String occupation, String socialClass, String previousCountry) {
        this.nid = nid;
        this.fname = fname;
        this.lname = lname;
        this.dob = dob;
        this.email = email;
        this.phone = phone;
        this.status = status;
        this.children = children;
        this.occupation = occupation;
        this.socialClass = socialClass;
        this.previousCountry = previousCountry;
    }

    public int getNid() {
        return nid;
    }

    public void setNid(int nid) {
        this.nid = nid;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public int getChildren() {
        return children;
    }

    public void setChildren(int children) {
        this.children = children;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }

    public String getSocialClass() {
        return socialClass;
    }

    public void setSocialClass(String socialClass) {
        this.socialClass = socialClass;
    }

    public String getPreviousCountry() {
        return previousCountry;
    }

    public void setPreviousCountry(String previousCountry) {
        this.previousCountry = previousCountry;
    }
}
