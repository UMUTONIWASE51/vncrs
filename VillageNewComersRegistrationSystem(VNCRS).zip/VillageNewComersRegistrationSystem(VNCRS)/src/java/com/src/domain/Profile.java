/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.src.domain;

import java.time.LocalDate;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

/**
 *
 * @author emmanuel
 */
public class Profile {
    private String fname;
    private String lname;
    private LocalDate dob;
    private String email;
    private String phone;
    @Enumerated(EnumType.STRING)
    private Status status;
    private String occupation;
    private int children;

    public Profile() {
    }

    public Profile(String fname, String lname, LocalDate dob, String email, String phone, Status status, String occupation, int children) {
        this.fname = fname;
        this.lname = lname;
        this.dob = dob;
        this.email = email;
        this.phone = phone;
        this.status = status;
        this.occupation = occupation;
        this.children = children;
    }

    public int getChildren() {
        return children;
    }

    public void setChildren(int children) {
        this.children = children;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public LocalDate getDob() {
        return dob;
    }

    public void setDob(LocalDate dob) {
        this.dob = dob;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        this.occupation = occupation;
    }
}
