/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.src.service;

import com.src.dao.GeneralDao;
import com.src.domain.Children;
import com.src.domain.Person;
import com.src.domain.PreviousCountry;
import com.src.domain.Profile;
import com.src.domain.Property;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author emmanuel
 */
public class RegistrationServiceImpl implements RegistrationService{

    private Person person = new Person();
    GeneralDao<Person> personDao = new GeneralDao<>(Person.class);

    public RegistrationServiceImpl() {
    }
    
    
    
    private boolean isExistPerson(int nid){
        if(personDao.findByINT_PK(nid) == null){
            return false;
        }
        
        return true;
    }
    
    public String generateSocialClass(Property prop){
        
        if(prop.isCar() && prop.isHouse() && prop.isFurnitures()){
            return "Upper";
        }else if(prop.isCar() && prop.isHouse()){
            return "Middle";
        }else if(prop.isHouse() && prop.isFurnitures()){
            return "Working";
        }else{
           return "poor"; 
        }
    }
    
    
    @Override
    public Person registerNewPerson(int nid, Profile prof, Property prop, PreviousCountry prevC) {
        
        try {
            if(isExistPerson(nid)){
                throw new RuntimeException("Person Arleady Registered");
            }
            
            String socialClass = generateSocialClass(prop);
            String previousCountry = prevC.getCode();
            
            person = new Person(nid, prof.getFname(), prof.getLname(), prof.getDob(), prof.getEmail(), prof.getPhone(), prof.getStatus(), prof.getChildren(), prof.getOccupation(), socialClass, previousCountry);
            
            Person retPerson = personDao.create(person);
            if(retPerson != null){
                return retPerson;
            }
            throw new RuntimeException("System Message: validation Error");
        } catch (Exception e) {
            throw new RuntimeException("Internal Server Error: "+e.getMessage());
        }
    }
}
