/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.src.service;

import com.src.domain.Person;
import com.src.domain.Property;
import com.src.domain.Profile;
import com.src.domain.PreviousCountry;
/**
 *
 * @author emmanuel
 */
public interface RegistrationService {
    public Person registerNewPerson(int nid, Profile prof, Property prop, PreviousCountry prevC);
}
